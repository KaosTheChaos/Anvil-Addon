	import { world, system, ItemStack, EnchantmentType } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { ChestFormData } from './chest/forms.js';

let items = [
    ["minecraft:netherite_sword", "textures/items/netherite_sword", "Netherite Sword"],
    ["minecraft:diamond_sword", "textures/items/diamond_sword", "Diamond Sword"],
    ["minecraft:iron_sword", "textures/items/iron_sword", "Iron Sword"],
    ["minecraft:golden_sword", "textures/items/gold_sword", "Golden Sword"],
    ["minecraft:stone_sword", "textures/items/stone_sword", "Stone Sword"],
    ["minecraft:wooden_sword", "textures/items/wood_sword", "Wooden Sword"],
    ["minecraft:netherite_pickaxe", "textures/items/netherite_pickaxe", "Netherite Pickaxe"],
    ["minecraft:diamond_pickaxe", "textures/items/diamond_pickaxe", "Diamond Pickaxe"],
    ["minecraft:iron_pickaxe", "textures/items/iron_pickaxe", "Iron Pickaxe"],
    ["minecraft:golden_pickaxe", "textures/items/gold_pickaxe", "Golden Pickaxe"],
    ["minecraft:stone_pickaxe", "textures/items/stone_pickaxe", "Stone Pickaxe"],
    ["minecraft:wooden_pickaxe", "textures/items/wood_pickaxe", "Wooden Pickaxe"],
    ["minecraft:netherite_axe", "textures/items/netherite_axe", "Netherite Axe"],
    ["minecraft:diamond_axe", "textures/items/diamond_axe", "Diamond Axe"],
    ["minecraft:iron_axe", "textures/items/iron_axe", "Iron Axe"],
    ["minecraft:golden_axe", "textures/items/gold_axe", "Golden Axe"],
    ["minecraft:stone_axe", "textures/items/stone_axe", "Stone Axe"],
    ["minecraft:wooden_axe", "textures/items/wood_axe", "Wooden Axe"],
    ["minecraft:netherite_shovel", "textures/items/netherite_shovel", "Netherite Shovel"],
    ["minecraft:diamond_shovel", "textures/items/diamond_shovel", "Diamond Shovel"],
    ["minecraft:iron_shovel", "textures/items/iron_shovel", "Iron Shovel"],
    ["minecraft:golden_shovel", "textures/items/gold_shovel", "Golden Shovel"],
    ["minecraft:stone_shovel", "textures/items/stone_shovel", "Stone Shovel"],
    ["minecraft:wooden_shovel", "textures/items/wood_shovel", "Wooden Shovel"],
    ["minecraft:netherite_hoe", "textures/items/netherite_hoe", "Netherite Hoe"],
    ["minecraft:diamond_hoe", "textures/items/diamond_hoe", "Diamond Hoe"],
    ["minecraft:iron_hoe", "textures/items/iron_hoe", "Iron Hoe"],
    ["minecraft:golden_hoe", "textures/items/gold_hoe", "Golden Hoe"],
    ["minecraft:stone_hoe", "textures/items/stone_hoe", "Stone Hoe"],
    ["minecraft:wooden_hoe", "textures/items/wood_hoe", "Wooden Hoe"],
    ["minecraft:mace", "textures/items/mace", "Mace"],
    ["minecraft:crossbow", "textures/items/crossbow_standby", "Crossbow"],
    ["minecraft:bow", "textures/items/bow_standby", "Bow"],
    ["minecraft:flint_and_steel", "textures/items/flint_and_steel", "Flint and Steel"],
    ["minecraft:shears", "textures/items/shears", "Shears"],
    ["minecraft:trident", "textures/items/trident", "Trident"],
    ["minecraft:shield", "textures/items/shield", "Shield"],
    ["minecraft:brush", "textures/items/brush", "Brush"],
    ["minecraft:turtle_helmet", "textures/items/turtle_helmet", "Turtle Helmet"],
    ["minecraft:fishing_rod", "textures/items/fishing_rod_uncast", "Fishing Rod"],
    ["minecraft:carrot_on_a_stick", "textures/items/carrot_on_a_stick", "Carrot on a Stick"],
    ["minecraft:warped_fungus_on_a_stick", "textures/items/warped_fungus_on_a_stick", "Warped Fungus on a Stick"],
    ["minecraft:elytra","textures/items/elytra","Elytra"],
    ["minecraft:netherite_helmet", "textures/items/netherite_helmet", "Netherite Helmet"],
    ["minecraft:diamond_helmet", "textures/items/diamond_helmet", "Diamond Helmet"],
    ["minecraft:iron_helmet", "textures/items/iron_helmet", "Iron Helmet"],
    ["minecraft:golden_helmet", "textures/items/gold_helmet", "Golden Helmet"],
    ["minecraft:chainmail_helmet", "textures/items/chainmail_helmet", "Chainmail Helmet"],
    ["minecraft:netherite_chestplate", "textures/items/netherite_chestplate", "Netherite Chestplate"],
    ["minecraft:diamond_chestplate", "textures/items/diamond_chestplate", "Diamond Chestplate"],
    ["minecraft:iron_chestplate", "textures/items/iron_chestplate", "Iron Chestplate"],
    ["minecraft:golden_chestplate", "textures/items/gold_chestplate", "Golden Chestplate"],
    ["minecraft:chainmail_chestplate", "textures/items/chainmail_chestplate", "Chainmail Chestplate"],  
    ["minecraft:netherite_leggings", "textures/items/netherite_leggings", "Netherite Leggings"],
    ["minecraft:diamond_leggings", "textures/items/diamond_leggings", "Diamond Leggings"],
    ["minecraft:iron_leggings", "textures/items/iron_leggings", "Iron Leggings"],
    ["minecraft:golden_leggings", "textures/items/gold_leggings", "Golden Leggings"],
    ["minecraft:chainmail_leggings", "textures/items/chainmail_leggings", "Chainmail Leggings"],
    
    ["minecraft:netherite_boots", "textures/items/netherite_boots", "Netherite Boots"],
    ["minecraft:diamond_boots", "textures/items/diamond_boots", "Diamond Boots"],
    ["minecraft:iron_boots", "textures/items/iron_boots", "Iron Boots"],
    ["minecraft:golden_boots", "textures/items/gold_boots", "Golden Boots"],
    ["minecraft:chainmail_boots", "textures/items/chainmail_boots", "Chainmail Boots"]
]

world.afterEvents.itemUse.subscribe(data => {
const player = data.source;
	if (data.itemStack.typeId !== 'kaos:anvil') return;
	if (true) {
	anvil(player);
	}	
	
});


function anvil(player) {
const form = new ActionFormData();
form.title(`§dAnvil+`);
form.body("");
form.button("§aRepair","textures/ui/anvil_icon");
form.button("§aItem Name","textures/items/name_tag");
form.button("§a Merge", "textures/items/kaos_anvil");
form.button("§cClose", "textures/ui/out");   
form.show(player).then(result => {
if (result.selection === 0) {
repairitem(player)
} 
if (result.selection === 1) {
itemnameinv(player)
}
if (result.selection === 2) {
merge(player, "noslot", "noslot")
}
})}

function repairitem(player) {
const inventory = player.getComponent("minecraft:inventory").container;
	const form = new ChestFormData('inv')
		form.title('Inventory')
  for (let i = 0; i < inventory.size; i++) {
const item = inventory.getItem(i);           
if (item == undefined) continue;
var encid = "none";
var enclist = ``;
var itemenchant = false;
try {
const enchantments = item.getComponent("enchantable").getEnchantments();
if (enchantments.length > 0) {
encid = enchantments.map(e => ({...e, type: e.type.id}))
 enclist = enchantments.map((ench) => `§7\n${ench.type.id.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')} ${ench.level}`);

itemenchant = true;

}
} catch (error) {} 
var durability = "none";
var durabilitydamage = false;
var maxdurability = "none"
try {
maxdurability = item.getComponent("durability").maxDurability;
durability = item.getComponent("durability").damage;
durabilitydamage = true;
} catch (error) {}
const itemdurability = maxdurability-durability;
      let temp = []
    for (const a of items){
            temp.push(a)
            if (item.typeId == a[0]) {
           if (durability > 0) {
if (item.nameTag == undefined) {
if (durabilitydamage == true && itemenchant == true) {
		form.button(i, a[2] + " x" + item.amount, [enclist, '','§7Durability', "§7" + maxdurability + "/" + itemdurability], a[1], item.amount, itemenchant)
}	
if (durabilitydamage == true && itemenchant == false) {
		form.button(i, a[2] + " x" + item.amount, ['','§7Durability', "§7" + maxdurability + "/" + itemdurability], a[1], item.amount, itemenchant)
}
if (durabilitydamage == false && itemenchant == true) {
		form.button(i, a[2] + " x" + item.amount, [enclist], a[1], item.amount, itemenchant)
}	
if (durabilitydamage == false && itemenchant == false) {
		form.button(i, a[2] + " x" + item.amount, [''], a[1], item.amount, itemenchant)
}
}
if (item.nameTag !== undefined) {
if (durabilitydamage == true && itemenchant == true) {
		form.button(i, item.nameTag + " §rx" + item.amount, [enclist, '','§7Durability', "§7" + maxdurability + "/" + itemdurability], a[1], item.amount, itemenchant)
}	
if (durabilitydamage == true && itemenchant == false) {
		form.button(i, item.nameTag + " §rx" + item.amount, ['','§7Durability', "§7" + maxdurability + "/" + itemdurability], a[1], item.amount, itemenchant)
}
if (durabilitydamage == false && itemenchant == true) {
		form.button(i, item.nameTag + " §rx" + item.amount, [enclist], a[1], item.amount, itemenchant)
}	
if (durabilitydamage == false && itemenchant == false) {
		form.button(i, item.nameTag + " §rx" + item.amount, [''], a[1], item.amount, itemenchant)
}
}
}
}}}
		
		form.show(player).then(response => {
		const slot = response.selection;
		if (response.selection+1 > 0) {
		repair(player, slot)	
		}})
}

function repair(player, slot) {
const inventory = player.getComponent("minecraft:inventory").container;
  for (let i = 0; i < inventory.size; i++) {
var item = inventory.getItem(slot);           
if (item == undefined) continue;
var encid = "none";
var itemenchant = false;
try {
const enchantments = item.getComponent("enchantable").getEnchantments();
if (enchantments.length > 0) {
encid = enchantments.map(e => ({...e, type: e.type.id}))

itemenchant = true;

}
} catch (error) {} 
var durability = "none";
var durabilitydamage = false;
try {
durability = item.getComponent("durability").damage;
if (durability !== 0) {
durabilitydamage = true;
}
} catch (error) {}
}
if (durabilitydamage == true) {
const itemid = item.typeId;
const amount = item.amount;
const name = item.nameTag;
giveitem(player, itemid, encid, slot, amount, name, itemenchant);
player.sendMessage("§aItem Repaired.")
player.playSound("random.anvil_use")

} else {
player.sendMessage("§cYou Cannot Repair This Item.");
}
}


function giveitem(player, itemid, encid, slot, amount, name, itemenchant, a, durability) {
const inv = player.getComponent("inventory").container;
const item = new ItemStack(itemid, amount);
if (itemenchant == true) {
     const ench = item.getComponent("enchantable");
    ench.addEnchantments(encid.map(e => ({ ...e, type: new EnchantmentType(e.type) })))
}
if (a == "a") {
if (durability > 0) {
const durabilitys = item.getComponent("durability");
    durabilitys.damage = durability;
}}
if (name !== undefined) {
item.nameTag = name;
}
inv.setItem(slot, item);
}

function itemnameinv(player) {
const inventory = player.getComponent("minecraft:inventory").container;
	const form = new ChestFormData('inv')
		form.title('Inventory')
  for (let i = 0; i < inventory.size; i++) {
const item = inventory.getItem(i);           
if (item == undefined) continue;
var encid = "none";
var enclist = ``;
var itemenchant = false;
try {
const enchantments = item.getComponent("enchantable").getEnchantments();
if (enchantments.length > 0) {
encid = enchantments.map(e => ({...e, type: e.type.id}))
 enclist = enchantments.map((ench) => `§7\n${ench.type.id.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')} ${ench.level}`);

itemenchant = true;

}
} catch (error) {} 
var durability = "none";
var durabilitydamage = false;
var maxdurability = "none"
try {
maxdurability = item.getComponent("durability").maxDurability;
durability = item.getComponent("durability").damage;
durabilitydamage = true;
} catch (error) {}
const itemdurability = maxdurability-durability;
      let temp = []
    for (const a of items){
            temp.push(a)
            if (item.typeId == a[0]) {
if (item.nameTag == undefined) {
if (durabilitydamage == true && itemenchant == true) {
		form.button(i, a[2] + " x" + item.amount, [enclist, '','§7Durability', "§7" + maxdurability + "/" + itemdurability], a[1], item.amount, itemenchant)
}	
if (durabilitydamage == true && itemenchant == false) {
		form.button(i, a[2] + " x" + item.amount, ['','§7Durability', "§7" + maxdurability + "/" + itemdurability], a[1], item.amount, itemenchant)
}
if (durabilitydamage == false && itemenchant == true) {
		form.button(i, a[2] + " x" + item.amount, [enclist], a[1], item.amount, itemenchant)
}	
if (durabilitydamage == false && itemenchant == false) {
		form.button(i, a[2] + " x" + item.amount, [''], a[1], item.amount, itemenchant)
}
}
if (item.nameTag !== undefined) {
if (durabilitydamage == true && itemenchant == true) {
		form.button(i, item.nameTag + " §rx" + item.amount, [enclist, '','§7Durability', "§7" + maxdurability + "/" + itemdurability], a[1], item.amount, itemenchant)
}	
if (durabilitydamage == true && itemenchant == false) {
		form.button(i, item.nameTag + " §rx" + item.amount, ['','§7Durability', "§7" + maxdurability + "/" + itemdurability], a[1], item.amount, itemenchant)
}
if (durabilitydamage == false && itemenchant == true) {
		form.button(i, item.nameTag + " §rx" + item.amount, [enclist], a[1], item.amount, itemenchant)
}	
if (durabilitydamage == false && itemenchant == false) {
		form.button(i, item.nameTag + " §rx" + item.amount, [''], a[1], item.amount, itemenchant)
}
}
}
if (item.typeId == "minecraft:name_tag") {
if (item.nameTag !== undefined) {
form.button(i, item.nameTag + " §rx" + item.amount, [''], "textures/items/name_tag", item.amount)
} else {
form.button(i, "NameTag" + " §rx" + item.amount, [''], "textures/items/name_tag", item.amount)
}}
}}
		
		form.show(player).then(response => {
		const slot = response.selection;
		if (response.selection+1 > 0) {
		itemname(player, slot)	
		}})
}

function itemname(player, slot) {
const modal = new ModalFormData();
modal.title(`Item Name`);
modal.textField("Name","...");
modal.show(player).then(result => {
const name = result.formValues[0]
if (name !== "") {
itemname1(player, slot, name)
} else {
player.sendMessage(`§cInvalid Name.`);
}
})
}

function itemname1(player, slot, name) {
const inventory = player.getComponent("minecraft:inventory").container;
  for (let i = 0; i < inventory.size; i++) {
var item = inventory.getItem(slot);           
if (item == undefined) continue;
var encid = "none";
var itemenchant = false;
try {
const enchantments = item.getComponent("enchantable").getEnchantments();
if (enchantments.length > 0) {
encid = enchantments.map(e => ({...e, type: e.type.id}))

itemenchant = true;

}
} catch (error) {} 
var durability = "none";
var durabilitydamage = false;
try {
durability = item.getComponent("durability").damage;
if (durability !== 0) {
durabilitydamage = true;
}
} catch (error) {}
}

const itemid = item.typeId;
const amount = item.amount;
giveitem(player, itemid, encid, slot, amount, "§r" + name, itemenchant, "a", durability)
player.sendMessage("§aItem Name Changed Successfully.")
player.playSound("random.orb")

}

function merge(player, slot1, slot2) {
var item1 = "";
var item2 = "";
	const form = new ChestFormData('anvil')
		form.title('Merge')
		if (slot1 == "noslot") {
		form.button(19, 'Item 1', ['§cYou Can Only Put Books or Tools Here!!'], 'textures/ui/anvil-plus')
		
		} else {
const inventory = player.getComponent("minecraft:inventory").container;
const item = inventory.getItem(slot1);    
item1 = item.typeId;       
var encid = "none";
var enclist = ``;
var itemenchant = false;
try {
const enchantments = item.getComponent("enchantable").getEnchantments();
if (enchantments.length > 0) {
encid = enchantments.map(e => ({...e, type: e.type.id}))
 enclist = enchantments.map((ench) => `§7\n${ench.type.id.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')} ${ench.level}`);

itemenchant = true;

}
} catch (error) {} 
var durability = "none";
var durabilitydamage = false;
var maxdurability = "none"
try {
maxdurability = item.getComponent("durability").maxDurability;
durability = item.getComponent("durability").damage;
durabilitydamage = true;
} catch (error) {}
const itemdurability = maxdurability-durability;

      let temp = []
    for (const a of items){
            temp.push(a)
            if (item.typeId == a[0]) {
       
if (item.nameTag == undefined) {
if (durabilitydamage == true && itemenchant == true) {
		form.button(19, a[2] + " x" + item.amount, [enclist, '','§7Durability', "§7" + maxdurability + "/" + itemdurability], a[1], item.amount, itemenchant)
}	
if (durabilitydamage == true && itemenchant == false) {
		form.button(19, a[2] + " x" + item.amount, ['','§7Durability', "§7" + maxdurability + "/" + itemdurability], a[1], item.amount, itemenchant)
}
if (durabilitydamage == false && itemenchant == true) {
		form.button(19, a[2] + " x" + item.amount, [enclist], a[1], item.amount, itemenchant)
}	
if (durabilitydamage == false && itemenchant == false) {
		form.button(19, a[2] + " x" + item.amount, [''], a[1], item.amount, itemenchant)
}
}
if (item.nameTag !== undefined) {
if (durabilitydamage == true && itemenchant == true) {
		form.button(19, item.nameTag + " §rx" + item.amount, [enclist, '','§7Durability', "§7" + maxdurability + "/" + itemdurability], a[1], item.amount, itemenchant)
}	
if (durabilitydamage == true && itemenchant == false) {
		form.button(19, item.nameTag + " §rx" + item.amount, ['','§7Durability', "§7" + maxdurability + "/" + itemdurability], a[1], item.amount, itemenchant)
}
if (durabilitydamage == false && itemenchant == true) {
		form.button(19, item.nameTag + " §rx" + item.amount, [enclist], a[1], item.amount, itemenchant)
}	
if (durabilitydamage == false && itemenchant == false) {
		form.button(19, item.nameTag + " §rx" + item.amount, [''], a[1], item.amount, itemenchant)
}
}

}}

if (item.typeId == "minecraft:enchanted_book") {
		form.button(19, "Enchanted Book" + " §rx" + item.amount, [enclist], "textures/items/book_enchanted", item.amount, itemenchant)
}
}
				if (slot2 == "noslot") {
		form.button(22, 'Item 1', ['§cYou Can Only Put Books or Tools Here!!'], 'textures/ui/anvil-plus')
		} else {
const inventory = player.getComponent("minecraft:inventory").container;
const item = inventory.getItem(slot2);    
item2 = item.typeId;       
var encid = "none";
var enclist = ``;
var itemenchant = false;
try {
const enchantments = item.getComponent("enchantable").getEnchantments();
if (enchantments.length > 0) {
encid = enchantments.map(e => ({...e, type: e.type.id}))
 enclist = enchantments.map((ench) => `§7\n${ench.type.id.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')} ${ench.level}`);

itemenchant = true;

}
} catch (error) {} 
var durability = "none";
var durabilitydamage = false;
var maxdurability = "none"
try {
maxdurability = item.getComponent("durability").maxDurability;
durability = item.getComponent("durability").damage;
durabilitydamage = true;
} catch (error) {}
const itemdurability = maxdurability-durability;

      let temp = []
    for (const a of items){
            temp.push(a)
            if (item.typeId == a[0]) {
       
if (item.nameTag == undefined) {
if (durabilitydamage == true && itemenchant == true) {
		form.button(22, a[2] + " x" + item.amount, [enclist, '','§7Durability', "§7" + maxdurability + "/" + itemdurability], a[1], item.amount, itemenchant)
}	
if (durabilitydamage == true && itemenchant == false) {
		form.button(22, a[2] + " x" + item.amount, ['','§7Durability', "§7" + maxdurability + "/" + itemdurability], a[1], item.amount, itemenchant)
}
if (durabilitydamage == false && itemenchant == true) {
		form.button(22, a[2] + " x" + item.amount, [enclist], a[1], item.amount, itemenchant)
}	
if (durabilitydamage == false && itemenchant == false) {
		form.button(22, a[2] + " x" + item.amount, [''], a[1], item.amount, itemenchant)
}
}
if (item.nameTag !== undefined) {
if (durabilitydamage == true && itemenchant == true) {
		form.button(22, item.nameTag + " §rx" + item.amount, [enclist, '','§7Durability', "§7" + maxdurability + "/" + itemdurability], a[1], item.amount, itemenchant)
}	
if (durabilitydamage == true && itemenchant == false) {
		form.button(22, item.nameTag + " §rx" + item.amount, ['','§7Durability', "§7" + maxdurability + "/" + itemdurability], a[1], item.amount, itemenchant)
}
if (durabilitydamage == false && itemenchant == true) {
		form.button(22, item.nameTag + " §rx" + item.amount, [enclist], a[1], item.amount, itemenchant)
}	
if (durabilitydamage == false && itemenchant == false) {
		form.button(22, item.nameTag + " §rx" + item.amount, [''], a[1], item.amount, itemenchant)
}
}

}}
if (item.typeId == "minecraft:enchanted_book") {
		form.button(22, "Enchanted Book" + " §rx" + item.amount, [enclist], "textures/items/book_enchanted", item.amount, itemenchant)
}
}

if (item2 !== "minecraft:enchanted_book" && item1 !== item2 && slot1 !== "noslot" && slot2 !== "noslot") {
		form.button(25, '§cWarning', ['§cThese Two Items Cannot Be Combined'], 'textures/blocks/barrier')
		}
if ( slot1 !== "noslot" && slot2 !== "noslot") {
	if (item1 == item2 || item2 == "minecraft:enchanted_book")
		form.button(25, '§aNice!!', ['§aClick To Merge'], 'textures/ui/anvil_icon')
		} 
		
form.show(player).then(response => {
if (response.selection == 25) {
mergetest(player, slot1, slot2)
}
if (response.selection == 19) {
mergeinv(player, slot1, slot2, "1", slot2)
}
if (response.selection == 22) {
mergeinv(player, slot1, slot2, "2", slot1)
}
})}

function mergeinv(player, slot1, slot2, s, ss) {
const inventory = player.getComponent("minecraft:inventory").container;
	const form = new ChestFormData('inv')
		form.title('Inventory')
  for (let i = 0; i < inventory.size; i++) {
const item = inventory.getItem(i);           
if (item == undefined) continue;
var encid = "none";
var enclist = ``;
var itemenchant = false;
try {
const enchantments = item.getComponent("enchantable").getEnchantments();
if (enchantments.length > 0) {
encid = enchantments.map(e => ({...e, type: e.type.id}))
 enclist = enchantments.map((ench) => `§7\n${ench.type.id.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')} ${ench.level}`);
itemenchant = true;
}
} catch (error) {} 
var durability = "none";
var durabilitydamage = false;
var maxdurability = "none"
try {
maxdurability = item.getComponent("durability").maxDurability;
durability = item.getComponent("durability").damage;
durabilitydamage = true;
} catch (error) {}
const itemdurability = maxdurability-durability;
      let temp = []
    for (const a of items){
            temp.push(a)
            if (i !== ss) {
            if (item.typeId == a[0]) {
if (item.nameTag == undefined) {
if (durabilitydamage == true && itemenchant == true) {
		form.button(i, a[2] + " x" + item.amount, [enclist, '','§7Durability', "§7" + maxdurability + "/" + itemdurability], a[1], item.amount, itemenchant)
}	
if (durabilitydamage == true && itemenchant == false) {
		form.button(i, a[2] + " x" + item.amount, ['','§7Durability', "§7" + maxdurability + "/" + itemdurability], a[1], item.amount, itemenchant)
}
if (durabilitydamage == false && itemenchant == true) {
		form.button(i, a[2] + " x" + item.amount, [enclist], a[1], item.amount, itemenchant)
}	
if (durabilitydamage == false && itemenchant == false) {
		form.button(i, a[2] + " x" + item.amount, [''], a[1], item.amount, itemenchant)
}
}
if (item.nameTag !== undefined) {
if (durabilitydamage == true && itemenchant == true) {
		form.button(i, item.nameTag + " §rx" + item.amount, [enclist, '','§7Durability', "§7" + maxdurability + "/" + itemdurability], a[1], item.amount, itemenchant)
}	
if (durabilitydamage == true && itemenchant == false) {
		form.button(i, item.nameTag + " §rx" + item.amount, ['','§7Durability', "§7" + maxdurability + "/" + itemdurability], a[1], item.amount, itemenchant)
}
if (durabilitydamage == false && itemenchant == true) {
		form.button(i, item.nameTag + " §rx" + item.amount, [enclist], a[1], item.amount, itemenchant)
}	
if (durabilitydamage == false && itemenchant == false) {
		form.button(i, item.nameTag + " §rx" + item.amount, [''], a[1], item.amount, itemenchant)
}
}
}
}
}
if (i !== ss) {
if (item.typeId == "minecraft:enchanted_book") {
		form.button(i, "Enchanted Book" + " §rx" + item.amount, [enclist], "textures/items/book_enchanted", item.amount, itemenchant)
}}
}
		
		form.show(player).then(response => {
		const slot = response.selection;
		if (response.selection+1 > 0) {
		if (s == "1") { 
		merge(player, slot, slot2)	
		}
				if (s == "2") { 
		merge(player, slot1, slot)	
		}
		}})
}


function mergetest(player, slot1, slot2) {
    const inv = player.getComponent("minecraft:inventory").container;
    const item = inv.getItem(slot1);    
    const items = inv.getItem(slot2);   
    var itemenchant = false;

    try {
        const enchantments = items.getComponent("enchantable").getEnchantments();
        
        if (enchantments.length > 0) {
            itemenchant = true;
            const ench = item.getComponent("enchantable");
            
            enchantments.forEach(e => {
                if (ench.canAddEnchantment(e)) {
                    ench.addEnchantment(e);  
                }
            });
        }
    } catch (error) {}

    if (itemenchant == true) {
        inv.setItem(slot1, item);
        inv.setItem(slot2, new ItemStack("minecraft:barrier", 1));    
        player.sendMessage("§aMerge Successful.");
        player.playSound("random.anvil_use");
        player.runCommand(`clear @s barrier`);
    }
}


